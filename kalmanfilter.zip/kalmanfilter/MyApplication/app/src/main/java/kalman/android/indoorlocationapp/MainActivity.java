package kalman.android.indoorlocationapp;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.location.*;
import android.util.Log;
import android.location.*;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Vector;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;


public class MainActivity extends AppCompatActivity implements SensorEventListener, LocationListener {


    double Accaverage = 0.0;
    double Gpsaverage = 0.0;
    int n = 0;
    int m = 0;
    int GPS_CONST = 40;
    int ACC_CONST = 40;
    double AccstandardDeviation = 0.0;
    double GpsstandardDeviation = 0.0;
    double[] linearAcc = new double[100];
    double[] Gpsposdata = new double[100];
    SensorManager mSensorManager;
    Sensor mSensor;
    TriggerEventListener mTriggerEventListener;
    boolean GpsisFirst = true;
    boolean AccDeviationCalculated = false;
    boolean GpsDeviationCalculated = false;
    boolean AppStarts = false;
    boolean SensorsettingKalman = false;
    boolean GpssettingKalman = false;
    double initialLatitude;
    double initialLongitude;
    double[] gravity = new double[1];
    KalmanFilterFusedPositionAccelerometer kalmanX;
    TextView tv1;
    TextView tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = (TextView)findViewById(R.id.Xcoord);
        tv2 = (TextView)findViewById(R.id.VelocityX);
    }


    @Override
    protected void onStart() {
        super.onStart();
        main();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
    /*
        if (!AccDeviationCalculated) {
            if (n < ACC_CONST) {
                // In this example, alpha is calculated as t / (t + dT),
                // where t is the low-pass filter's time-constant and
                // dT is the event delivery rate.

                final double alpha = 0.8;

                // Isolate the force of gravity with the low-pass filter.
                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];

                Accaverage += event.values[0] - gravity[0];
                linearAcc[n] = event.values[0] - gravity[0];
                double xValue = event.values[0] - gravity[0];
                Log.d("X Axis", "x:" + xValue);
                n++;
            } else {
                for (int i = 0; i < ACC_CONST; i++) {
                    AccstandardDeviation += Math.pow((Accaverage / ACC_CONST) - linearAcc[i], 2);
                }
                AccstandardDeviation = AccstandardDeviation / ACC_CONST;
                Log.d("AccStandardDeviation", Double.toString(AccstandardDeviation));
                AccDeviationCalculated = true;
                if ((!AppStarts) && (AccDeviationCalculated) && (GpsDeviationCalculated)&&(kalmanX==null)&&(GpssettingKalman==false)&&(SensorsettingKalman==false)) {
                    SensorsettingKalman = true;
                    double initialtimestamp = System.currentTimeMillis() / 1000;
                    kalmanX = NewKalmanFilterFusedPositionAccelerometer(0.0, GpsstandardDeviation, AccstandardDeviation, initialtimestamp);
                    AppStarts = true;
                }
            }
        } else {
            if ((AppStarts)&&(AccDeviationCalculated)&&(GpsDeviationCalculated)&&(kalmanX!=null)){
                double currenttimestamp = System.currentTimeMillis() / 1000;
                kalmanX.Predict(event.values[0], currenttimestamp);
                Log.d("Predict", "Predict Called" + event.values[0] + " " + currenttimestamp);
                Log.d("Readings", Double.toString(kalmanX.GetPredictedPosition())+ " "+Double.toString(kalmanX.GetPredictedVelocityThisAxis()));
                tv1.setText(Double.toString(kalmanX.GetPredictedPosition()));
                tv2.setText(Double.toString(kalmanX.GetPredictedVelocityThisAxis()));
            }
        }*/
    }

    public double measure(double lat1, double lon1, double lat2, double lon2) {  // generally used geo measurement function
        double R = 6378.137; // Radius of earth in KM
        double dLat = lat2 * Math.PI / 180 - lat1 * Math.PI / 180;
        double dLon = lon2 * Math.PI / 180 - lon1 * Math.PI / 180;
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = R * c;
        return d * 1000; // meters
    }

    public void main() {
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensor = null;

        /*if (mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null){
            List<Sensor> AccSensors = mSensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
            for(int i=0; i<AccSensors.size(); i++) {
                if (AccSensors.get(i) != null){
                    // Use available raw sensor
                    mSensor = AccSensors.get(i);
                }
            }
        }*/
        if (mSensor == null) {
            // Use the accelerometer.
            if (mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
                mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

                mTriggerEventListener = new TriggerEventListener() {
                    @Override
                    public void onTrigger(TriggerEvent event) {
                        // Do work
                if (!AccDeviationCalculated) {
                            if (n < ACC_CONST) {
                                // In this example, alpha is calculated as t / (t + dT),
                                // where t is the low-pass filter's time-constant and
                                // dT is the event delivery rate.

                                final double alpha = 0.8;

                                // Isolate the force of gravity with the low-pass filter.
                                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];

                                Accaverage += event.values[0] - gravity[0];
                                linearAcc[n] = event.values[0] - gravity[0];
                                double xValue = event.values[0] - gravity[0];
                                Log.d("X Axis", "x:" + xValue);
                                n++;
                            } else {
                                for (int i = 0; i < ACC_CONST; i++) {
                                    AccstandardDeviation += Math.pow((Accaverage / ACC_CONST) - linearAcc[i], 2);
                                }
                                AccstandardDeviation = AccstandardDeviation / ACC_CONST;
                                Log.d("AccStandardDeviation", Double.toString(AccstandardDeviation));
                                AccDeviationCalculated = true;
                                if ((!AppStarts) && (AccDeviationCalculated) && (GpsDeviationCalculated)&&(kalmanX==null)&&(GpssettingKalman==false)&&(SensorsettingKalman==false)) {
                                    SensorsettingKalman = true;
                                    double initialtimestamp = System.currentTimeMillis() / 1000;
                                    kalmanX = NewKalmanFilterFusedPositionAccelerometer(0.0, GpsstandardDeviation, AccstandardDeviation, initialtimestamp);
                                    AppStarts = true;
                                }
                            }
                        } else {
                            if ((AppStarts)&&(AccDeviationCalculated)&&(GpsDeviationCalculated)&&(kalmanX!=null)){
                                double currenttimestamp = System.currentTimeMillis() / 1000;
                                kalmanX.Predict(event.values[0], currenttimestamp);
                                Log.d("Predict", "Predict Called" + event.values[0] + " " + currenttimestamp);
                                Log.d("Readings", Double.toString(kalmanX.GetPredictedPosition())+ " "+Double.toString(kalmanX.GetPredictedVelocityThisAxis()));
                                tv1.setText(Double.toString(kalmanX.GetPredictedPosition()));
                                tv2.setText(Double.toString(kalmanX.GetPredictedVelocityThisAxis()));
                            }}}};

                mSensorManager.requestTriggerSensor(mTriggerEventListener, mSensor);

            } else {
                Log.d("Accelerometer", "Accelerometer not found");
                // Sorry, there are no accelerometers on your device.
                // You can't play this game.
            }
        }

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }

    @Override
    public void onLocationChanged(Location location) {

        if (!GpsDeviationCalculated) {
            if (GpsisFirst) {
                initialLatitude = location.getLatitude();
                initialLongitude = location.getLongitude();
                GpsisFirst = false;
            }
            // Called when a new location is found by the network location provider.
            if (m < GPS_CONST) {
                Gpsposdata[m] = measure(location.getLatitude(), location.getLongitude(), initialLatitude, initialLongitude);
                Gpsaverage += Gpsposdata[m];
                Log.d("Position", Double.toString(Gpsposdata[m]));
                m++;
            } else {
                for (int i = 0; i < GPS_CONST; i++) {
                    GpsstandardDeviation += Math.pow(((Gpsaverage / GPS_CONST) - Gpsposdata[i]), 2);
                }
                GpsstandardDeviation = GpsstandardDeviation / GPS_CONST;
                Log.d("GpsstandardDeviation", Double.toString(GpsstandardDeviation));
                GpsDeviationCalculated = true;
                if ((!AppStarts) && (AccDeviationCalculated) && (GpsDeviationCalculated)&&(kalmanX==null)&&(GpssettingKalman==false)&&(SensorsettingKalman==false)) {
                    GpssettingKalman = true;
                    double initialtimestamp = System.currentTimeMillis() / 1000;
                    kalmanX = NewKalmanFilterFusedPositionAccelerometer(0.0, GpsstandardDeviation, AccstandardDeviation, initialtimestamp);
                    AppStarts = true;
                }
            }
        } else {
            if ((AppStarts)&&(AccDeviationCalculated)&&(GpsDeviationCalculated)&&(kalmanX!=null)){
                //Updates KALMAN FILTER
                double tempLatitude = location.getLatitude();
                double tempSpeed = location.getSpeed();
                kalmanX.Update(tempLatitude, tempSpeed);
                Log.d("Update","Kalman updated "+ tempLatitude+ " "+ tempSpeed);
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    Matrix NewMatrix(int numrows, int numcolumns) {
        Array newData = new Array(numrows*numcolumns);
        Matrix temp = new Matrix(newData, numrows, numcolumns);
        return temp;
    }
    Matrix NewIdentityMatrix(int rows, int columns) {
        if(rows != columns){
            Log.d("Matrix","Identity matrix should be square");
        }
        Matrix temp = NewMatrix(rows, columns);
        int c = 0;
        for(int r = 0; r < rows; r++){
            temp.Put(r, c, 1);
            c++;
        }
        return temp;
    }

    public KalmanFilterFusedPositionAccelerometer NewKalmanFilterFusedPositionAccelerometer(double initialPosition,
                                                                                            double positionStandardDeviation,
                                                                                            double accelerometerStandardDeviation,
                                                                                            double currentTimestampSeconds) {

        Matrix currentState = NewMatrix(2, 1);

        currentState.Put(0, 0, initialPosition);
        currentState.Put(1, 0, 0.0);

        Matrix u = NewMatrix(1, 1);
        Matrix z = NewMatrix(2, 1);
        Matrix H = NewIdentityMatrix(2, 2);
        Matrix P = NewIdentityMatrix(2, 2);

        Matrix Q = NewMatrix(2, 2);
        Q.Put(0, 0, accelerometerStandardDeviation * accelerometerStandardDeviation);
        Q.Put(1, 1, accelerometerStandardDeviation * accelerometerStandardDeviation);

        Matrix R = NewMatrix(2, 2);
        R.Put(0, 0, positionStandardDeviation * positionStandardDeviation);
        // TODO might need to play with this value
        R.Put(1, 1, positionStandardDeviation * positionStandardDeviation);
        Matrix B = NewMatrix(2, 1);
        Matrix A = NewMatrix(2, 2);

        KalmanFilterFusedPositionAccelerometer temp = new KalmanFilterFusedPositionAccelerometer(H, P, Q, R, u, z, A, B, currentState, currentTimestampSeconds);
        return temp;

    }
};