package kalman.android.indoorlocationapp;

import android.util.Log;

import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by root on 17/11/17.
 */



public class KalmanFilterFusedPositionAccelerometer {
    Matrix H; // transformation matrix for input data
    Matrix P;                          // initial guess for covariance
    Matrix Q;                         // process (accelerometer) error variance
    Matrix R,                           // measurement (GPS) error variance
            u,                            // INPUT control (accelerometer) matrix
            z,                            // INPUT measurement (GPS) matrix
            A,                            // State Transition matrix
            B,                            // Control matrix
            currentState;
    double currentStateTimestampSeconds;


    KalmanFilterFusedPositionAccelerometer(Matrix H, Matrix P, Matrix Q, Matrix R, Matrix u, Matrix z, Matrix A, Matrix B, Matrix currentState, double currentStateTimestampSeconds) {
        this.H = H;
        this.P = P;
        this.Q = Q;
        this.R = R;
        this.u = u;
        this.z = z;
        this.A = A;
        this.B = B;
        this.currentState = currentState;
        this.currentStateTimestampSeconds = currentStateTimestampSeconds;
    }


    public void CopyMatrix(Matrix A, Matrix B) {
        if ((A.rows == B.rows) && (A.columns == B.columns)) {
            for (int row = 0; row < B.rows; row++)
                for (int column = 0; column < B.columns; column++)
                    A.Put(row, column, B.Get(row, column));
        }
    }

    Matrix NewMatrix(int rows, int cols) {
        Array newData = new Array(rows * cols);
        Matrix temp = new Matrix(newData, rows, cols);
        /*Arrayrefrences.set(newData.Arrdata);
        Matrixrefrences.set(temp);*/
        return temp;
    }

    Matrix NewIdentityMatrix(int rows, int columns) {
        if (rows != columns) {
            Log.d("Matrix", "Identity matrix should be square");
        }
        Matrix temp = NewMatrix(rows, columns);
        int c = 0;
        for (int r = 0; r < rows; r++) {
            temp.Put(r, c, 1);
            c++;
        }
        return temp;
    }

    public void Predict(double accelerationThisAxis, double timestampNow) {
        double deltaT = timestampNow - currentStateTimestampSeconds;

        this.recreateControlMatrix(deltaT);
        this.recreateStateTransitionMatrix(deltaT);

        this.u.Put(0, 0, accelerationThisAxis);

        Matrix obj1 = NewMatrix(2, 1);
        CopyMatrix(obj1, (this.A).MultipliedBy(this.currentState));
        Matrix obj2 = NewMatrix(2, 1);
        CopyMatrix(obj2, (this.B).MultipliedBy(this.u));
        Matrix obj3 = NewMatrix(2, 1);
        CopyMatrix(obj3, (obj1).Add(obj2));
        CopyMatrix(this.currentState, obj3);

        Matrix temp1 = NewMatrix(2, 2);//A*P
        CopyMatrix(temp1, (this.A).MultipliedBy(this.P));
        Matrix temp2 = NewMatrix(2, 2);//A.Transpose()
        CopyMatrix(temp2, (this.A).Transpose());
        Matrix temp3 = NewMatrix(2, 2);//temp1*temp2
        CopyMatrix(temp3, (temp1).MultipliedBy(temp2));
        Matrix temp4 = NewMatrix(2, 2);//temp3+Q
        CopyMatrix(temp4, (temp3).Add(this.Q));
        CopyMatrix(this.P, temp4);

        this.currentStateTimestampSeconds = timestampNow;
    }

    public void Update(double position, double velocityThisAxis) {

        this.z.Put(0, 0, position);
        this.z.Put(1, 0, velocityThisAxis);

        Matrix y = this.z.Subtract(this.currentState);
        Matrix s = this.P.Add(this.R);
        Errmat sInverse = s.Inverse();
        if (sInverse.err != null) {
            // matrix has no inverse, abort
            return;
        }
        Matrix K = this.P.MultipliedBy(sInverse.mat);

        this.currentState = this.currentState.Add(K.MultipliedBy(y));

        this.P = (NewIdentityMatrix(2, 2).Subtract(K)).MultipliedBy(this.P);

	/*
		above is equivalent to:
			updatedP := k.P.Subtract(K.MultipliedBy(k.P))

		which would explain some confusion on the internets
	*/
    }

    public void recreateControlMatrix(double deltaSeconds) {
        double dtSquared = 0.5 * deltaSeconds * deltaSeconds;

        this.B.Put(0, 0, dtSquared);
        this.B.Put(1, 0, deltaSeconds);
    }

    public void recreateStateTransitionMatrix(double deltaSeconds) {
        this.A.Put(0, 0, 1.0);
        this.A.Put(0, 1, deltaSeconds);

        this.A.Put(1, 0, 0.0);
        this.A.Put(1, 1, 1.0);
    }

    public double GetPredictedPosition() {
        return this.currentState.Get(0, 0);
    }

    public double GetPredictedVelocityThisAxis() {
        return this.currentState.Get(1, 0);
    }
};



