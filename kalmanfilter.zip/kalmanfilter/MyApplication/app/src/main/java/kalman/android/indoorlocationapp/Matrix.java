package kalman.android.indoorlocationapp;

import android.util.Log;
import java.lang.Math;
import java.util.ArrayList;
import java.util.ArrayList;

/**
 * Created by root on 17/11/17.
 */

class Array{
    public ArrayList<Double> Arrdata;
    public int size;

    Array(int newsize){
        Arrdata = new ArrayList<Double>(newsize);
        for(int i=0;i<newsize;i++){
            Arrdata.add(0.000);
        }
        size = newsize;
    }
}
class Errmat{
    Matrix mat; String err;
    Errmat(Matrix newmat, String newerr){
        mat = newmat;
        err = newerr;
    }
};

class Matrix{
    /*ArrayList<ArrayList<Double>> Arrayrefrences;
    ArrayList<Matrix> Matrixrefrences;
    ArrayList<Errmat> Errmatreferences;*/
    Array data;
    int rows;
    int columns;

    public Matrix(Array newData, int newRows, int newCols){
    data = new Array(newData.size);
     if(!newData.Arrdata.isEmpty()){
     for(int i=0; i<newData.size;i++){
         data.Arrdata.set(i, newData.Arrdata.get(i));}}
     //Deleting newData Refrence from ArrayList
        /*
     for(ArrayList<Double> d : Arrayrefrences){
         if(d==newData.Arrdata){
             Arrayrefrences.remove(d);
         }*/
     rows = newRows;
     columns = newCols;
    }

    Matrix NewMatrix(int numrows, int numcolumns) {
        Array newData = new Array(numrows*numcolumns);
        Matrix temp = new Matrix(newData, numrows, numcolumns);
        /*Arrayrefrences.set(newData.Arrdata);
        Matrixrefrences.set(temp);*/
        return temp;
    }

    public int rowColToOffset(int row, int column) {
        int offset = (columns)*(row) + column;
        return offset;
    }
    public void Put(int row,int column,double value){
        data.Arrdata.set(rowColToOffset(row, column), value);
    }

    public double Get(int row,int column){
        return data.Arrdata.get(rowColToOffset(row, column));
    }

   public Array getRow(int row){
        int startIndex = rowColToOffset(row, 0);
        int endIndex = startIndex + columns;
        Array newArray = new Array(columns);
       if(!data.Arrdata.isEmpty()){
        for(int i=0; i<columns;i++){
          newArray.Arrdata.set(i, data.Arrdata.get(startIndex+i));}}
        //Arrayrefrences.set(newArray.Arrdata);
        return newArray;
    }

   public Array getCol(int col){
        Array returnValues = new Array(rows);
        for(int r = 0; r < rows; r++){
            if(!(getRow(r).Arrdata.isEmpty())){
            returnValues.Arrdata.set(r, getRow(r).Arrdata.get(col));
        }}
        //Arrayrefrences.set(returnValues.Arrdata);
        return returnValues;
    }

   public Matrix MultipliedByScalar(double value){
        Array newData = new Array(data.size);
        if(!data.Arrdata.isEmpty()){
        for(int i = 0; i < data.size; i++){
            newData.Arrdata.set(i, (data.Arrdata.get(i) * value));
        }}
        Matrix temp = new Matrix(newData, rows, columns);
        //Arrayrefrences.set(newData.Arrdata);
        //Matrixrefrences.set(temp);
        return temp;
    }

    public Matrix MultipliedBy(Matrix otherMatrix){
        if(columns != otherMatrix.rows){
            Log.d("Matrix","Matrices are not compatible for multiplication");
        }
        Matrix resultantMatrix = NewMatrix(rows, otherMatrix.columns);
        for(int r = 0; r < rows; r++){
            for(int c = 0; c < otherMatrix.columns; c++){
                Array row = this.getRow(r);
                Array col = otherMatrix.getCol(c);
                double value = 0.0;
                for(int i = 0; i < row.size; i++){
                    value += row.Arrdata.get(i)*col.Arrdata.get(i);
                }
                resultantMatrix.Put(r, c, value);
            }
        }
        //Removing otherMatrix from Matrixrefrences
        /*for(Matrix d : Matrixrefrences){
            if(d==otherMatrix){
                Matrixrefrences.remove(d);
            }
        }*/
        return resultantMatrix;
    }

    public Matrix Transpose(){
        Matrix transpose = NewMatrix(columns, rows);

        for(int r = 0; r < rows; r++){
            Array row = this.getRow(r);

            int transposeCol = r;
            for(int i = 0; i < row.size; i++){
                transpose.Put(i, transposeCol, row.Arrdata.get(i));
            }
        }
        return transpose;
    }

    public Matrix Add(Matrix otherMatrix){
        if((this.rows != otherMatrix.rows)|| (this.columns != otherMatrix.columns)){
            Log.d("Matrix","Cannot add matrices of different dimensions");
        }
        Array newData = new Array(data.size);
        if(!data.Arrdata.isEmpty()){
        for(int i = 0; i < data.size; i++){
            newData.Arrdata.set(i, data.Arrdata.get(i) + otherMatrix.data.Arrdata.get(i));
        }}
        Matrix temp = new Matrix(newData, rows, columns);
        /*Arrayrefrences.set(newData.Arrdata);
        Matrixrefrences.set(temp);
        //Removing otherMatrix from Matrixrefrences
        for(Matrix d : Matrixrefrences){
            if(d==otherMatrix){
                Matrixrefrences.remove(d);
            }
        }*/
        return temp;
    }

    public Matrix Subtract(Matrix otherMatrix){
        if((rows != otherMatrix.rows)||(columns != otherMatrix.columns)){
            Log.d("Matrix","Cannot add matrices of different dimensions");
        }
        Array newData = new Array(data.size);
        if(!data.Arrdata.isEmpty()){
        for(int i = 0; i < data.size; i++){
            newData.Arrdata.set(i, data.Arrdata.get(i) - otherMatrix.data.Arrdata.get(i));
        }}
        Matrix temp = new Matrix(newData, rows, columns);
        /*Arrayrefrences.set(newData.Arrdata);
        Matrixrefrences.set(temp);
        //Removing otherMatrix from Matrixrefrences
        for(Matrix d : Matrixrefrences){
            if(d==otherMatrix){
                Matrixrefrences.remove(d);
            }
        }*/
        return temp;
    }

    double Determinant(){
        if(rows != columns){
            Log.d("Matrix","Cannot take the determinant of a non-square matrix");
        }
        if(rows == 1){
            return this.Get(0, 0);
        } else if(rows == 2){
            return this.Get(0, 0)*this.Get(1, 1) - this.Get(0, 1)*this.Get(1, 0);
        } else {
            int sign = 1;
            double total = 0.0;
            int r = 0;
            for(int c = 0; c < columns; c++){
                double value = this.Get(r, c);
                value *= this.MatrixExcludingRowAndCol(r, c).Determinant();
                value *= sign;
                sign *= -1;
                total += value;
            }
            return total;
        }
    }

    public Matrix MatrixExcludingRowAndCol(int omitRow,int omitCol){
        int newSize = (rows - 1) * (columns - 1);
        Array newData = new Array(newSize);

        int newIndex = 0;
        // SBL I THINK THERE MIGHT BE AN ERROR HERE...m.row == omitRow??
        for(int i = 0; i < data.size; i++){
            if((i / columns) == omitRow){
                continue;
            } else if((i % columns) == omitCol){
                continue;
            }
            newData.Arrdata.set(newIndex, data.Arrdata.get(i));
            newIndex++;
        }
        Matrix temp = new Matrix(newData, rows-1,columns-1);
        /*Arrayrefrences.set(newData.Arrdata);
        Matrixrefrences.set(temp);*/
        return temp;
    }

    public Errmat Inverse(){
        if(rows != columns){
            Log.d("Matrix","Cannot take inverse of a non-square matrix");
        }
        if(this.Determinant() == 0){
            Errmat temp = new Errmat(null, "Cannot take inverse of matrix");
            //Errmatreferences.set(temp);
            return temp;
        }
        Matrix newMatrix = NewMatrix(rows, columns);
        if((rows == 1) && (columns == 1)){
            // this is a special case hack, but it should be ok...
            if(this.Get(0, 0) == 0.0){
                Errmat temp = new Errmat(null, "Cannot take inverse of matrix");
                //Errmatreferences.set(temp);
                return temp;
            }
            newMatrix.Put(0, 0, 1.0/this.Get(0, 0));
            Errmat temp = new Errmat(newMatrix, null);
            //Errmatreferences.set(temp);
            return temp;
        }
        for(int r = 0; r < rows; r++){
            int sign = 1;
            if(r%2 == 1){
                sign = -1;
            }
            for(int  c = 0; c < columns; c++){
                newMatrix.Put(r, c, (sign)*MatrixExcludingRowAndCol(r, c).Determinant());

                sign *= -1;
            }
        }
        Matrix diagSwapped = newMatrix.Transpose();
        Errmat temp = new Errmat(diagSwapped.MultipliedByScalar((1.0)/(this.Determinant())), null);
        //Errmatreferences.set(temp);
        return temp;
    }

    public void PrettyPrint() {
        for(int r = 0; r < rows; r++){
            for(int c = 0; c < columns; c++){
                Log.d("Print",Double.toString(this.Get(r, c)));
            }
            Log.d("Blank","\n");
        }
    }

    public Errmat GetCholeskyDecomposition(){
        Matrix cholesky = NewMatrix(rows, rows);
        double preSqrtL = this.Get(0, 0);
        if(preSqrtL < 0.0){
            Errmat temp = new Errmat(null, "Cannot take cholesky decomposition");
            //Errmatreferences.set(temp);
            return temp;
        }
        Matrix previousL = NewMatrix(1, 1);
        previousL.Put(0, 0, Math.sqrt(preSqrtL));

        for(int r = 0; r < previousL.rows; r++){
            for(int c = 0; c < previousL.columns; c++){
                cholesky.Put(r, c, previousL.Get(r, c));
            }
        }

        for(int aLength = 1; aLength < rows; aLength++){
            Matrix nextArrayList = NewMatrix(aLength, 1);
            for(int r = 0; r < aLength; r++){
                nextArrayList.Put(r, 0, this.Get(r, aLength));
            }
            double diagA = this.Get(aLength, aLength);

            // previousL * intermediate = nextArrayList
            Errmat inversePrevious = previousL.Inverse();
            if(inversePrevious.err != null){
                Errmat temp = new Errmat(null, "Cannot take cholesky because of inverse matrix failure");
                //Errmatreferences.set(temp);
                return temp;
            }
            Matrix intermediate = (inversePrevious.mat).MultipliedBy(nextArrayList);

            preSqrtL = diagA - intermediate.Transpose().MultipliedBy(intermediate).Get(0, 0);
            if(preSqrtL < 0.0){
                Errmat temp = new Errmat(null, "Cannot take cholesky decomposition");
                //Errmatreferences.set(temp);
                Log.d("Cholesky","Cannot take cholesky decomposition");
                return temp;
            }
            double diagVal = Math.sqrt(preSqrtL);
            Matrix temp = NewMatrix(previousL.rows+1, previousL.columns+1);
            for(int r = 0; r < previousL.rows; r++){
                for(int c = 0; c < previousL.columns; c++){
                    temp.Put(r, c, previousL.Get(r, c));
                }
            }
            previousL = temp;
            previousL.Put(aLength, aLength, diagVal);

            for(int c = 0; c < aLength; c++){
                previousL.Put(aLength, c, intermediate.Get(c, 0));
            }

            for(int r = 0; r < previousL.rows; r++){
                for(int c = 0; c < previousL.columns; c++){
                    cholesky.Put(r, c, previousL.Get(r, c));
                }
            }
        }
        Errmat temp = new Errmat(cholesky, null);
        //Errmatreferences.set(temp);
        return temp;
        // TODO: to migreate to Java, make sure I account for my inverse matrix function, make this piece more efficient
    }
};



